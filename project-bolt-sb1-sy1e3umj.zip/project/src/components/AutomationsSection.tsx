import { Timeline } from "./ui/timeline";

export const AutomationsSection = () => {
  const data = [
    {
      title: "Agentic Chat Agents",
      image: "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=800&h=600&fit=crop",
      bullets: [
        "Reduce wait time by 555x",
        "Instant lead qualification",
        "Dramatically improved customer experience"
      ]
    },
    {
      title: "Agentic Voice Agents",
      image: "https://images.unsplash.com/photo-1553484771-371a605b060b?w=800&h=600&fit=crop",
      bullets: [
        "Available 24/7, no sick days",
        "Natural, human-like conversations",
        "Handles multiple calls simultaneously"
      ]
    },
    {
      title: "AI Automations",
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=600&fit=crop",
      bullets: [
        "Automated lead routing & scoring",
        "Smart document generation",
        "Intelligent follow-up sequences"
      ]
    },
  ];

  return <Timeline data={data} />;
};
