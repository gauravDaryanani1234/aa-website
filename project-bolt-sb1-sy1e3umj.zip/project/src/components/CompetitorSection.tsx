import { motion } from "framer-motion";
import { Clock, Cpu, Wrench, ArrowRight } from "lucide-react";

const carouselData = [
  {
    title: "YOU ARE RUNNING\nOUT OF TIME",
    description: "Every minute spent on admin tasks is a minute NOT showing properties or closing deals.\n\nYour competitors are automating their workflows, responding to leads instantly, and scaling their operations.",
    icon: Clock,
  },
  {
    title: "AI ISN'T THE FUTURE ANYMORE\nIT'S THE PRESENT.",
    description: "24/7 AI agents are capturing leads while you sleep.\n\nThey're answering questions, scheduling viewings, and qualifying prospects around the clock.\n\nThe real estate market never stops, and neither should your lead generation.",
    icon: Cpu,
  },
  {
    title: "YOUR COMPETITION HAS\nALREADY ADAPTED",
    description: "Real estate is moving faster than ever - manual processes are costing you deals.\n\nTop performers are leveraging AI for instant property recommendations, automated market analysis, and predictive client insights.\n\nThey're closing deals faster, managing more clients, and delivering better service.",
    icon: Wrench,
  },
];

export const CompetitorSection = () => {
  return (
    <section className="min-h-screen w-full bg-slate-950 flex flex-col items-center justify-center px-4 pb-20">
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        viewport={{ once: true }}
        className="text-4xl md:text-5xl lg:text-6xl font-medium text-center bg-clip-text text-transparent bg-gradient-to-b from-neutral-100 to-neutral-400 mb-20 pb-2"
      >
        Your Competitors Are Already Using AI.
      </motion.h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl w-full mb-16">
        {carouselData.map((item, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: index * 0.2 }}
            viewport={{ once: true }}
            whileHover={{
              scale: 1.05,
              transition: { duration: 0.3 }
            }}
            className="group relative bg-slate-900/50 backdrop-blur-sm border-2 border-white rounded-2xl pt-16 px-10 pb-10 hover:border-blue-400 transition-all duration-300 min-h-[400px] flex flex-col"
          >
            <div className="absolute -top-8 left-1/2 -translate-x-1/2 w-16 h-16 rounded-full border-2 border-white bg-slate-900 flex items-center justify-center flex-shrink-0 z-20">
              <span className="text-2xl font-bold text-white">{index + 1}</span>
            </div>

            <div className="absolute inset-0 rounded-2xl overflow-hidden">
              <motion.div
                className="absolute inset-0 bg-gradient-to-br from-blue-600/10 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"
              />

              <motion.div
                className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-in-out"
                style={{
                  background: 'linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent)',
                  width: '50%',
                }}
              />
            </div>

            <div className="relative z-10 flex flex-col h-full items-center">
              {item.icon && (
                <item.icon className="w-12 h-12 text-white mb-6 flex-shrink-0" />
              )}

              <h3 className="text-2xl font-bold text-neutral-100 mb-4 group-hover:text-blue-400 transition-colors duration-300 text-center whitespace-pre-line">
                {item.title}
              </h3>

              <div className="w-full border-t border-white mb-6"></div>

              <p className="text-neutral-400 leading-relaxed text-lg group-hover:text-neutral-300 transition-colors duration-300 text-center whitespace-pre-line">
                {item.description}
              </p>
            </div>

            <motion.div
              className="absolute -inset-0.5 bg-gradient-to-r from-blue-600 to-cyan-600 rounded-2xl opacity-0 group-hover:opacity-20 blur transition-opacity duration-300 -z-10"
            />
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.4 }}
        viewport={{ once: true }}
        className="flex justify-center w-full"
      >
        <button
          onClick={() => document.getElementById('booking-section')?.scrollIntoView({ behavior: 'smooth' })}
          className="group relative flex items-center gap-2 px-8 py-4 rounded-lg bg-transparent border-2 border-white text-white font-medium text-lg transition-all duration-300 hover:border-blue-400 overflow-hidden"
        >
          <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-in-out" style={{ background: 'linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent)', width: '50%' }} />
          <span className="relative z-10">Book a Call</span>
          <ArrowRight className="w-5 h-5 relative z-10" />
        </button>
      </motion.div>
    </section>
  );
};
