import { useState } from "react";
import { Menu, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export const Navigation = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const menuItems = [
    { label: "Home", href: "#hero-section" },
    { label: "Services", href: "#services-section" },
    { label: "Contact", href: "#booking-section" },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-[100] px-6 py-6 bg-transparent">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-3 relative">
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="group relative flex items-center gap-2 px-6 py-2 rounded-lg bg-slate-950 border-2 border-white hover:border-blue-900 transition-all duration-300 text-white font-medium overflow-hidden"
          >
            <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-in-out" style={{ background: 'linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent)', width: '50%' }} />
            {isMenuOpen ? <X className="w-5 h-5 relative z-10" /> : <Menu className="w-5 h-5 relative z-10" />}
            <span className="relative z-10">MENU</span>
          </button>

          <AnimatePresence>
            {isMenuOpen && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="absolute top-14 left-0 bg-slate-900/95 backdrop-blur-sm border border-neutral-800 rounded-lg shadow-xl overflow-hidden min-w-[200px]"
              >
                {menuItems.map((item, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      const element = document.getElementById(item.href.replace('#', ''));
                      element?.scrollIntoView({ behavior: 'smooth' });
                      setIsMenuOpen(false);
                    }}
                    className="block w-full text-left px-6 py-3 text-neutral-300 hover:text-blue-400 hover:bg-slate-800/50 transition-colors duration-200 border-b border-neutral-800 last:border-b-0"
                  >
                    {item.label}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="absolute left-1/2 -translate-x-1/2">
          <img
            src="https://res.cloudinary.com/djywdg08a/image/upload/v1761742461/PWs_logo_bz2wox.png"
            alt="Logo"
            className="h-[42px] w-auto"
          />
        </div>

        <button
          onClick={() => document.getElementById('booking-section')?.scrollIntoView({ behavior: 'smooth' })}
          className="group relative px-6 py-2 rounded-lg bg-slate-950 border-2 border-white hover:border-blue-900 text-white font-medium transition-all duration-300 overflow-hidden"
        >
          <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-in-out" style={{ background: 'linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent)', width: '50%' }} />
          <span className="relative z-10">Book a Call</span>
        </button>
      </div>
    </nav>
  );
};
