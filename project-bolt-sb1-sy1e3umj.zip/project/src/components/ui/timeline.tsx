import {
  useScroll,
  useTransform,
  motion,
} from "framer-motion";
import { useEffect, useRef, useState } from "react";

interface TimelineEntry {
  title: string;
  image: string;
  bullets: string[];
}

export const Timeline = ({ data }: { data: TimelineEntry[] }) => {
  const ref = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [height, setHeight] = useState(0);

  useEffect(() => {
    if (ref.current) {
      const rect = ref.current.getBoundingClientRect();
      setHeight(rect.height);
    }
  }, [ref]);

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start 10%", "end 50%"],
  });

  const heightTransform = useTransform(scrollYProgress, [0, 1], [0, height]);
  const opacityTransform = useTransform(scrollYProgress, [0, 0.1], [0, 1]);

  return (
    <div
      id="services-section"
      className="w-full bg-slate-950 font-sans md:px-10"
      ref={containerRef}
    >
      <div className="max-w-7xl mx-auto pt-20 px-4 md:px-8 lg:px-10">
        <h2 className="text-4xl md:text-5xl lg:text-6xl font-medium text-center bg-clip-text text-transparent bg-gradient-to-b from-neutral-100 to-neutral-400 mb-8 pb-4">
          Automations to<br />Maximize your Revenue
        </h2>
        <p className="text-neutral-400 text-base md:text-lg text-center max-w-3xl mx-auto">
          Transform your business with AI-powered solutions that work 24/7 to capture leads, qualify prospects, and automate operations.
        </p>
      </div>

      <div ref={ref} className="relative max-w-7xl mx-auto pb-20">
        {data.map((item, index) => (
          <div
            key={index}
            className="grid grid-cols-1 md:grid-cols-[1fr_auto_1fr] gap-8 md:gap-12 items-center pt-10 md:pt-20 px-4 md:px-8"
          >
            <div className="flex justify-center md:justify-end">
              <div className="w-full max-w-sm">
                <div className="rounded-3xl overflow-hidden border-4 border-blue-500/30 bg-gradient-to-br from-blue-500/20 to-purple-500/20 p-2">
                  <img
                    src={item.image}
                    alt={item.title}
                    className="rounded-2xl object-cover w-full h-64 md:h-80"
                  />
                </div>
              </div>
            </div>

            <div className="flex flex-col items-center relative">
              <div className="h-12 w-12 rounded-full bg-slate-900 border-2 border-white flex items-center justify-center z-10">
                <div className="h-6 w-6 rounded-full bg-blue-500 border border-blue-400" />
              </div>
            </div>

            <div className="flex justify-center md:justify-start">
              <div className="w-full max-w-sm">
                <div className="rounded-3xl bg-gradient-to-br from-blue-500/10 to-purple-500/10 border-2 border-blue-500/30 p-6">
                  <h3 className="text-2xl md:text-3xl font-bold text-neutral-100 mb-6">
                    {item.title}
                  </h3>
                  <ul className="space-y-4">
                    {item.bullets.map((bullet, idx) => (
                      <li key={idx} className="flex items-start gap-3 text-neutral-300 text-base md:text-lg">
                        <span className="text-blue-400 flex-shrink-0 mt-1">✓</span>
                        <span>{bullet}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        ))}
        <div
          style={{
            height: height + "px",
          }}
          className="hidden md:block absolute left-1/2 -translate-x-1/2 top-0 overflow-hidden w-[2px] bg-[linear-gradient(to_bottom,var(--tw-gradient-stops))] from-transparent from-[0%] via-neutral-700 to-transparent to-[99%] [mask-image:linear-gradient(to_bottom,transparent_0%,black_10%,black_90%,transparent_100%)]"
        >
          <motion.div
            style={{
              height: heightTransform,
              opacity: opacityTransform,
            }}
            className="absolute inset-x-0 top-0 w-[2px] bg-gradient-to-t from-blue-500 via-blue-400 to-transparent from-[0%] via-[10%] rounded-full"
          />
        </div>
      </div>
    </div>
  );
};
