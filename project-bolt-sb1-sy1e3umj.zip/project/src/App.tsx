import './App.css';
import { BackgroundCells } from './components/ui/background-ripple-effect';
import { CompetitorSection } from './components/CompetitorSection';
import { AutomationsSection } from './components/AutomationsSection';
import { CallToActionSection } from './components/CallToActionSection';
import { Navigation } from './components/Navigation';
import { ArrowRight } from 'lucide-react';

function App() {
  return (
    <div className="w-full">
      <Navigation />
      <BackgroundCells className="bg-slate-950" id="hero-section">
        <div className="flex flex-col items-center gap-20 -mt-0">
          <h1 className="md:text-2xl lg:text-7xl font-medium text-center bg-clip-text text-transparent bg-gradient-to-b from-neutral-100 to-neutral-400 pointer-events-none">
            AI Services <br />
            for Real Estate
          </h1>
          <div className="flex items-center gap-4 pointer-events-auto">
            <button
              onClick={() => document.getElementById('booking-section')?.scrollIntoView({ behavior: 'smooth' })}
              className="group relative flex items-center gap-2 px-6 py-3 rounded-lg bg-transparent border-2 border-white text-white font-medium transition-all duration-300 hover:border-blue-400 overflow-hidden"
            >
              <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-in-out" style={{ background: 'linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent)', width: '50%' }} />
              <span className="relative z-10">Book A Call</span>
              <ArrowRight className="w-5 h-5 relative z-10" />
            </button>
            <button
              onClick={() => document.getElementById('services-section')?.scrollIntoView({ behavior: 'smooth' })}
              className="group relative flex items-center gap-2 px-6 py-3 rounded-lg bg-transparent border-2 border-white text-white font-medium transition-all duration-300 hover:border-blue-400 overflow-hidden"
            >
              <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-in-out" style={{ background: 'linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent)', width: '50%' }} />
              <span className="relative z-10">Explore Services</span>
              <ArrowRight className="w-5 h-5 relative z-10" />
            </button>
          </div>
        </div>
      </BackgroundCells>
      <CompetitorSection />
      <AutomationsSection />
      <CallToActionSection />
    </div>
  );
}

export default App;
